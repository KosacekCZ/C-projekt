#include <stdio.h>

void drawSquare(int w, int h, int f) {
    for (int i = 0; i < h; i++) {
        // columns

        for (int j = 0; j < w + f; j++) {
            // lines

            // square
            if ((i == 0 || i == h - 1) && j < w) {
                printf("X");
            } else {
                if (j == 0 || j == w - 1) {
                    printf("X");
                } else if (w == h && j < w) {
                    if ((i + j) % 2 == 0) {
                        printf("o");
                    } else {
                        printf("*");
                    }
                    // fence
                } else if (j >= w && i > (h - f) - 1) {
                    if (i == (h - f) || i == (h - 1)) {
                        if ((j + f) % 2 == 0) {
                            printf("|");
                        } else {
                            printf("-");
                        }
                    } else {
                        if ((j + f) % 2 == 0) {
                            printf("|");
                        } else {
                            printf(" ");
                        }
                    }
                } else if (j < w) {
                    // infill : !w == h
                    printf(" ");
                }
            }
        }
        // newline
        printf("\n");
    }
}

void drawRoof(int w) {
    for (int i = 0; i < (w - 1) / 2; i++) {
        for (int j = 0; j <= w - 2; j++) {
            if (i == 0 && j == ((w + 1) / 2) - 1) {
                printf("X\n");
            } else if (i > 0 &&  (j == ((w + 1) / 2) - 1 - i)) {
                printf("X");
            } else if (i > 0 && (j == ((w + 1) / 2) - 1 + i)) {
                printf("X\n");
            } else if (j <= ((w + 1) / 2) - 1 + i) {
                printf(" ");
            }
        }
    }
}

int drawHouse(int w, int h, int f) {
    // check input range
    if ((w > 2 && w < 70) && (h > 2 && h < 70)) {
        // check width odd
        if (w % 2 == 1) {
            // check fence valid
            if (h > f) {
                drawRoof(w);
                drawSquare(w, h, f);
                return 0;
            } else {
                fprintf(stderr, "Error: Neplatna velikost plotu!\n");
                return 103;
            }
        } else {
            fprintf(stderr, "Error: Sirka neni liche cislo!\n");
            return 102;
        }
    } else {
        fprintf(stderr, "Error: Vstup mimo interval!\n");
        return 101;
    }
}

int main() {
    int w, h, f, checksum = 0;
    checksum += scanf("%d", &w);
    checksum += scanf("%d", &h);
    checksum += scanf("%d", &f);

    // test int entered
    if (checksum <= 6) {
        return drawHouse(w, h, f);
    } else {
        fprintf(stderr, "Error: Chybny vstup!\n");
        return 100;
    }
}
